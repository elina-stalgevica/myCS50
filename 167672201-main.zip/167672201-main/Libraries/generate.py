# Python comes with several libraries. This one is a "random".

from random import choice

# Randomly select between "heads" and "tails"
coin = choice(["heads", "tails"])

# Print the result
print(coin)

