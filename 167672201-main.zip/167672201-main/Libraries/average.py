# Python also comes with statistics library

import statistics

print(statistics.mean([100, 90]))
