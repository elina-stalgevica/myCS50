# How to print a bric 3x3
def main():
    print_square(3)

def print_square(size):
    for i in range(size):
        print("#" * size)

main()
